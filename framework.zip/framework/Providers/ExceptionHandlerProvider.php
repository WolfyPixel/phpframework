<?php


namespace Framework\Providers;


class ExceptionHandlerProvider extends Provider {

    function register() {
        echo __METHOD__ . "<br />";
    }

    function boot() {
        echo __METHOD__ . "<br />";
    }
}