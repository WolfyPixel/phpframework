<?php
// helpers

use Framework\Application;
use Framework\Services\Config;

/**
 * @param string|null $class
 * @return Application|mixed
 */

function app(string $class = null){
    $app = Application::instance();

    if(empty($class))
        return $app;

    return $app->get($class);
}

function config(string $key, $default = null){
    return app(Config::class)
        ->get($key, $default);
}